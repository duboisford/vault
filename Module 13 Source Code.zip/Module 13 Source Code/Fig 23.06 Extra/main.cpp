// Fig. 23.6: fig23_06.cpp
// Demonstrating operators .* and ->*.
#include <iostream>
using namespace std;

// class Test definition
class Test
{
public:
	Test(int v1, int v2) : value_1(v1), value_2(v2) {}

	void func_1()
	{
		cout << "In func 1\n";
	} // end function func

	void func_2()
	{
		cout << "In func 2\n";
	} // end function func

	int value_1; // public data member
	int value_2; // public data member
}; // end class Test

// Function takes object and member function pointer
void memberFunction(Test *object, void (Test::*function)() ) 
{
	cout << "object->*function: ";
	(object->*function)();	
}

// prototype takes object and member int pointer
void memberValue(Test *object, int Test::*vPtr)
{
	cout << "object->*vptr = " << object->*vPtr << endl;
}
void print(Test *test)
{
   cout << "\nCall Member Functions\n";
   memberFunction(test, &Test::func_1); // pass func_1 member address
   memberFunction(test, &Test::func_2); // pass func_2 member address

   cout << "\nMember Values\n";
   memberValue(test, &Test::value_1);	// pass value_1 member address
   memberValue(test, &Test::value_2);	// pass value_2 member address

}

int main()
{
   Test test1(100, 2000);
   print(&test1);

   Test test2(111, 2222);
   print(&test2);
} // end main


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
