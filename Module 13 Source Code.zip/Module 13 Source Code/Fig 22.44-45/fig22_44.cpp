// Fig. 22.44: fig22_44.cpp
// Using memcmp.
#include <iostream>
#include <iomanip>
#include <cstring> // memcmp prototype
using namespace std;

int main()
{
	// Fig 22.44 - memcmp
	{
		char s1[] = "ABCDEFG";
		char s2[] = "ABCDXYZ";

		cout << "\nFig 22.44 - memcmp\n";
		cout << "\ts1 = " << s1 << "\n\ts2 = " << s2 << endl
		<< "\n\tmemcmp(s1, s2, 4) = " << setw(3) << memcmp(s1, s2, 4)
		<< "\n\tmemcmp(s1, s2, 7) = " << setw(3) << memcmp(s1, s2, 7)
		<< "\n\tmemcmp(s2, s1, 7) = " << setw(3) << memcmp(s2, s1, 7)
		<< endl;
	}

	// Fig 22.45 - memchr
	{
		char s[] = "This is a string";

		cout << "\nFig 22.45 - memchr\n";

		cout << "\ts = " << s << "\n" << endl;
		cout << "\tThe remainder of s starting where character 'r' is found is \""
			<< static_cast< char * >(memchr(s, 'r', 16)) << '\"' << endl;
	}
} // end main

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
