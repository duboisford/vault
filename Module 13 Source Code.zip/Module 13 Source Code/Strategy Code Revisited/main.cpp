// Fig. 12.17: fig12_17.cpp
// Processing Employee derived-class objects individually 
// and polymorphically using dynamic binding.
#include <iostream>
#include <iomanip>
#include <vector>
#include "Employee.h"
#include "SalariedStrategy.h" 
#include "CommissionStrategy.h"  
#include "BasePlusCommissionStrategy.h" 
using namespace std;

// print all employees
void print(vector<Employee*> employees)
{
	cout << "\n\nAll Employees\n";

	for (const Employee *employee : employees)
	{
		employee->print();
		cout << "\tEarned: " << employee->earnings() << "\n\n";

	}
} // end print

int main()
{
	// set floating-point output formatting
	cout << fixed << setprecision(2);

	// create derived-class objects
	Employee SueJones("Sue", "Jones", "333-33-3333",
		new CommissionStrategy(10000, .06));
	Employee BobLewis("Bob", "Lewis", "444-44-4444",
		new BasePlusCommissionStrategy(3000, .04, 1000));
	Employee JohnSmith("John", "Smith", "111-11-1111",
		new SalariedStrategy(800));

	// create vector of three base-class pointers
	vector < Employee * > employees(3);

	// initialize vector with Employees
	employees[0] = &SueJones;
	employees[1] = &BobLewis;
	employees[2] = &JohnSmith;

	print(employees);

	// Promote Sue Jones to Bob Lewis old job
	SueJones.setEarningStratgey(new BasePlusCommissionStrategy(3000, .04, 1000));

	// Promote Bob Lewis to vice president: salary = 3,000
	BobLewis.setEarningStratgey(new SalariedStrategy(3000));

	// Give John Smith a 10% raise
		// downcast earningStrategy to salariedPtr
	SalariedStrategy *salariedPtr = dynamic_cast<SalariedStrategy *> (JohnSmith.getEarningStrategy());
	if (salariedPtr != nullptr)
		salariedPtr->setWeeklySalary( 1.1 * salariedPtr->getWeeklySalary());

	print(employees);

}// end main


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
