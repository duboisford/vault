// Earning.h
// Employee abstract base class.
#ifndef EARNING_H
#define EARNING_H

class EarningStrategy
{
public:
	virtual ~EarningStrategy() {}
	virtual double earnings() const = 0;
	virtual void print() const = 0;
};

#endif	// EARNING_H