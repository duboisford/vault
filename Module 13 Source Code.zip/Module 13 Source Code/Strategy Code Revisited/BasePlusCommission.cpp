// Fig. 12.12: SalariedEmployee.cpp
// SalariedEmployee class member-function definitions.
#include <iostream>
#include <stdexcept>
#include "BasePlusCommissionStrategy.h"
using namespace std;

// constructor 
BasePlusCommissionStrategy::BasePlusCommissionStrategy( double sales, double rate, double salary )
	: CommissionStrategy(sales, rate), SalariedStrategy(salary) 
	{ 
		// empty body
	} // end BasePlusCommissionStrategy constructor

// calculate earnings() for BasePlusCommission strategy
double BasePlusCommissionStrategy::earnings() const
{
	return SalariedStrategy::earnings() + CommissionStrategy::earnings();
} // end earnings()

// calculate print() for BasePlusCommission strategy
void BasePlusCommissionStrategy::print() const
{
	CommissionStrategy::print();
	SalariedStrategy::print();
} // end earnings()
