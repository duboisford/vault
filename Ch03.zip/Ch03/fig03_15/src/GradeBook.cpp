// Fig. 3.16: GradeBook.cpp
// Implementations of the GradeBook member-function definitions.
// The setCourseName function performs validation.
#include <iostream>
#include "GradeBook.h" // include definition of class GradeBook

// constructor initializes courseName with string supplied as argument
GradeBook::GradeBook(std::string courseName)
{
	setCourseName(courseName); // validate and store courseName
} // end GradeBook constructor

// function that sets the course name;
// ensures that the course name has at most 25 characters
void GradeBook::setCourseName(std::string courseName)
{
	if (courseName.size() <= 25) // if name has 25 or fewer characters
	{
		this->courseName = courseName; // store the course name in the object
	}
	else // if name has more than 25 characters
	{
		// set courseName to first 25 characters of parameter courseName
		this->courseName = courseName.substr(0, 25); // start at 0, length of 25

		std::cerr << "Name \"" << courseName
				<< "\" exceeds maximum length (25).\n"
				<< "Limiting courseName to first 25 characters.\n" << std::endl;
	} // end if
} // end function setCourseName

// function to get the course name
std::string GradeBook::getCourseName() const
{
	return this->courseName; // return object's courseName
} // end function getCourseName

// display a welcome message to the GradeBook user
void GradeBook::displayMessage() const
{
	// call getCourseName to get the courseName
	std::cout << "Welcome to the grade book for\n" << getCourseName() << "!"
			<< std::endl;
} // end function displayMessage
