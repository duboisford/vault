// Fig. 10.11: Array.cpp
// Array class member- and friend-function definitions
#include <exception>
#include <iostream>
#include <iomanip>
#include <stdexcept>
using namespace std;

#include "Array.h"

// Default constructor
Array::Array(int arraySize) :
      size(
            arraySize > 0 ?
                  arraySize :
                  throw invalid_argument("Array size must be greater than 0")), arrayPtr(
            new int[this->size])
{
   for (int i = 0; i < this->size; ++i)
   {
      this->arrayPtr[i] = 0; // set pointer-based array element
   }
} // end Array default constructor

// copy constructor for class Array;
// must receive a reference to an Array
Array::Array(const Array &arrayToCopy) :
      size(arrayToCopy.size), arrayPtr(new int[this->size])
{
   for (int i = 0; i < this->size; ++i)
   {
      this->arrayPtr[i] = arrayToCopy.arrayPtr[i]; // copy into object
   }
} // end Array copy constructor

// destructor for class Array
Array::~Array()
{
   delete[] this->arrayPtr; // release pointer-based array space
} // end destructor

// return number of elements of Array
int Array::getSize() const
{
   return this->size; // number of elements in Array
} // end function getSize

// overloaded assignment operator;
// const return avoids: ( a1 = a2 ) = a3
const Array &Array::operator=(const Array &right)
{
   if (&right != this) // avoid self-assignment
   {
      // for Arrays of different sizes, deallocate original
      // left-side Array, then allocate new left-side Array
      if (this->size != right.size)
      {
         delete[] this->arrayPtr; // release space
         this->size = right.size; // resize this object
         this->arrayPtr = new int[this->size]; // create space for Array copy
      } // end inner if

      for (int i = 0; i < this->size; ++i)
      {
         this->arrayPtr[i] = right.arrayPtr[i]; // copy array into object
      }
   } // end outer if

   return *this; // enables x = y = z, for example
} // end function operator=

// determine if two Arrays are equal and
// return true, otherwise return false
bool Array::operator==(const Array &right) const
{
   bool twoArraysAreEqual = true;
   if (this->size != right.size)
   {
      twoArraysAreEqual = false; // arrays of different number of elements
   }
   else
   {
      for (int i = 0; i < this->size; ++i)
      {
         if (this->arrayPtr[i] != right.arrayPtr[i])
         {
            twoArraysAreEqual = false; // Array contents are not equal
            break;
         }
      }
   }
   return twoArraysAreEqual; // Arrays are equal
} // end function operator==

// overloaded subscript operator for non-const Arrays;
// reference return creates a modifiable lvalue
int &Array::operator[](int subscript)
{
   // ensure subscript is in bounds
   if (subscript >= 0 && subscript < this->size)
   {
      return this->arrayPtr[subscript]; // reference return
   }
   else
   {
      throw out_of_range("Subscript out of range");
   }
} // end function operator[]

// overloaded subscript operator for const Arrays
// const reference return creates an rvalue
int Array::operator[](int subscript) const
{
   // ensure subscript is in bounds
   if (subscript >= 0 && subscript < this->size)
   {
      return this->arrayPtr[subscript]; // returns copy of this element
   }
   else
   {
      throw out_of_range("Subscript out of range");
   }
} // end function operator[]

// overloaded input operator for class Array;
// inputs values for entire Array
istream &operator>>(istream &input, Array &array)
{
   for (int i = 0; i < array.size; ++i)
   {
      input >> array.arrayPtr[i];
   }
   return input; // enables cin >> x >> y;
} // end function 

// overloaded output operator for class Array 
ostream &operator<<(ostream &output, const Array &array)
{
   int i;

   // output private ptr-based array 
   for (i = 0; i < array.size; ++i)
   {
      output << setw(12) << array.arrayPtr[i];

      if ((i + 1) % 4 == 0) // 4 numbers per row of output
      {
         output << endl;
      }
   } // end for

   if (i % 4 != 0) // end last line of output
   {
      output << endl;
   }

   return output; // enables cout << x << y;
} // end function operator<<

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
