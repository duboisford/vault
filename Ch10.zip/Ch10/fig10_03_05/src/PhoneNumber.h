// Fig. 10.3: PhoneNumber.h
// PhoneNumber class definition
#ifndef PHONENUMBER_H
#define PHONENUMBER_H

#include <iostream>
#include <string>

class PhoneNumber
{
public:
	const std::string& getAreaCode() const
	{
		return this->areaCode;
	}

	void setAreaCode(const std::string& areaCode)
	{
		this->areaCode = areaCode;
	}

	const std::string& getExchange() const
	{
		return this->exchange;
	}

	void setExchange(const std::string& exchange)
	{
		this->exchange = exchange;
	}

	const std::string& getLine() const
	{
		return this->line;
	}

	void setLine(const std::string& line)
	{
		this->line = line;
	}

private:
	std::string areaCode; // 3-digit area code
	std::string exchange; // 3-digit exchange
	std::string line; // 4-digit line
}; // end class PhoneNumber

std::ostream &operator<<(std::ostream& ostream, const PhoneNumber& number);
std::istream &operator>>(std::istream& istream, PhoneNumber& number);

#endif // PHONENUMBER_H

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
