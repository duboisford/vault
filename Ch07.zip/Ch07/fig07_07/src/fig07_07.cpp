// Fig. 7.7: fig07_07.cpp
// A const variable must be initialized.

int main()
{
	// TODO: Commented out so it will compile

//   const int x; // Error: x must be initialized
//
//   x = 7; // Error: cannot modify a const variable

   return 0;
} // end main
