/*
 * Test.h
 *
 *  Created on: Jun 12, 2014
 *      Author: DFerg_000
 */

#ifndef TEST_H_
#define TEST_H_

class Test {
public:
	Test();
	virtual ~Test();

private:
	 static const int tst [2] = {2, 3};
};

#endif /* TEST_H_ */
