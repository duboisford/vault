// Fig. 7.11: fig07_11.cpp
// Poll analysis program.
#include <iostream>
#include <iomanip>
#include <array>
using namespace std;

int main()
{
	// define array sizes
	const size_t TOT_SURVEY_RESPONSES = 20; // size of array responses
	const size_t TOT_RESPONSE_INDEX = 6; // size of array responseValueArr

	// place survey responses in array responses
	const array<unsigned int, TOT_SURVEY_RESPONSES> surveyResponseArr =
	{ 1, 2, 5, 4, 3, 5, 2, 1, 3, 1, 4, 3, 3, 3, 2, 3, 3, 2, 2, 5 };

	// initialize responseValueArr counters to 0
	array<unsigned int, TOT_RESPONSE_INDEX> ratingArr =
	{ };

	// for each answer, select responses element and use that value
	// as frequency subscript to determine element to increment
	for (size_t surveyIndex = 0; surveyIndex < surveyResponseArr.size();
			++surveyIndex)
	{
		++ratingArr[surveyResponseArr[surveyIndex]];
	}

	cout << "Rating" << setw(17) << "Frequency" << endl;

	// output each array element's value
	for (size_t ratingIndex = 1; ratingIndex < ratingArr.size(); ++ratingIndex)
	{
		cout << setw(6) << ratingIndex << setw(17) << ratingArr[ratingIndex]
				<< endl;
	}
} // end main
