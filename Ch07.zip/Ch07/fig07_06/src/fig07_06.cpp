// Fig. 7.6: fig07_06.cpp
// Using a properly initialized constant variable.
#include <iostream>
using namespace std;

int main()
{
   const int x = 7; // initialized constant variable

   cout << "The value of constant variable x is: " << x << endl;
} // end main
