// EarningDecorator.h
// Earning Decorator abstract base class.
#ifndef EARNINGDECORATOR_H
#define EARNINGDECORATOR_H

#include "EarningStrategy.h"

class EarningDecorator: public EarningStrategy
{
public:	
	friend class Employee;

	EarningDecorator(EarningStrategy *n) :next(n) {} // (inline) Constructor
	virtual ~EarningDecorator() { delete next; }

	EarningStrategy *getNext() const { return next; }

	virtual double earnings() const = 0;
	virtual void print() const = 0;

private:
	EarningStrategy *next;
};

#endif	// EARNINGDECORATOR_H