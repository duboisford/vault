// Bonus Decorator

#include "BonusDecorator.h"
#include <iostream>

using namespace std;

double BonusDecorator::earnings() const 
{
	return bonus + getNext()->earnings();
}

void BonusDecorator::print() const
{
	getNext()->print();
	cout << "\tBonus: " << getBonus() << endl;
}