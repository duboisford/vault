// Pension Decorator

#include "PensionDecorator.h"
#include <iostream>

using namespace std;

double PensionDecorator::earnings() const
{
	return (1.0 - getRate()) * getNext()->earnings();
}

void PensionDecorator::print() const
{
	getNext()->print();
	cout << "\tPension: -" << (getRate() * getNext()->earnings()) 
		<< " = " << getRate() << " X " << getNext()->earnings() << endl;
	
}