// Fig. 12.17: fig12_17.cpp
// Processing Employee derived-class objects individually 
// and polymorphically using dynamic binding.
#include <iostream>
#include <iomanip>
#include <vector>
#include "Employee.h"
#include "SalariedStrategy.h" 
#include "CommissionStrategy.h"  
#include "BasePlusCommissionStrategy.h"
#include "EarningDecorator.h"
#include "BonusDecorator.h"
#include "PensionDecorator.h"
using namespace std;

// print all employees
void print(vector<Employee*> employees)
{
	cout << "\n\nAll Employees\n";

	for (const Employee *employee : employees)
	{
		employee->print();

	}
} // end print

int main()
{
	// set floating-point output formatting
	cout << fixed << setprecision(2);

	// create derived-class objects
	Employee SueJones("Sue", "Jones", "333-33-3333",
		new CommissionStrategy(10000, .06));
	Employee BobLewis("Bob", "Lewis", "444-44-4444",
		new BasePlusCommissionStrategy(3000, .04, 1000));
	Employee JohnSmith("John", "Smith", "111-11-1111",
		new SalariedStrategy(800));

	// create vector of three base-class pointers
	vector < Employee * > employees(3);

	// initialize vector with Employees
	employees[0] = &SueJones;
	employees[1] = &BobLewis;
	employees[2] = &JohnSmith;

	print(employees);

	// Sue Jones pension deduction of 3%
	SueJones += new PensionDecorator(0.03);
	// And a $100.00 Bonus
	SueJones += new BonusDecorator(100.00);

	// Give Bob Lewis pension deduction of 4%
	BobLewis += new PensionDecorator(0.04);

	// Give John Smith a $50.00 Bonus
	JohnSmith += new BonusDecorator(50.00);

	print(employees);

}// end main


/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
