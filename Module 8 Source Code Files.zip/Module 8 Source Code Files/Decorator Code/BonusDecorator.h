// Bonus Decorator
#ifndef BONUSDECORATOR_H
#define BONUSDECORATOR_H
#include "EarningDecorator.h"

class BonusDecorator : public EarningDecorator
{
public:
	BonusDecorator(double b, EarningStrategy *n = nullptr) :EarningDecorator(n), bonus(b) {}

	double getBonus() const { return bonus; }

	double earnings() const override;
	void print() const override;
private:
	double bonus;
};
#endif //BONUSDECORATOR_H