// Pension Decorator
#ifndef PENSIONDECORATOR_H
#define PENSIONDECORATOR_H
#include "EarningDecorator.h"

class PensionDecorator : public EarningDecorator
{
public:
	PensionDecorator(double r, EarningStrategy *n = nullptr) :EarningDecorator(n), rate(r) {}

	double getRate() const { return rate; }

	double earnings() const override;
	void print() const override;
private:
	double rate;
};
#endif //PENSIONDECORATOR_H