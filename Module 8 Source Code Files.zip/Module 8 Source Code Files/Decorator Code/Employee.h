// Fig. 12.9: Employee.h
// Employee abstract base class.
#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string> // C++ standard string class
#include "EarningStrategy.h"
#include "EarningDecorator.h"

class Employee 
{
public:
   Employee( const std::string &first, const std::string &last, 
	   const std::string &ssn, EarningStrategy *earning);
   // destructor
   virtual ~Employee() 
   { 
	   delete earningStrategy; 
   }

   void setFirstName( const std::string & ); // set first name
   std::string getFirstName() const // return first name(inline)
   {
	   return firstName;
   }

   void setLastName( const std::string & ); // set last name
   std::string getLastName() const // return last name
   {
	   return lastName;
   }

   void setSocialSecurityNumber(const std::string &); // set SSN
   std::string getSocialSecurityNumber() const // return SSN
   {
	   return socialSecurityNumber;
   }

   void setEarningStratgey(EarningStrategy *strategy); // set earning strategy
   EarningStrategy *getEarningStrategy() const // return earning strategy
   {
	   return earningStrategy;
   }

   // 'delegates' earning to earningStrategy object
   double earnings() const
   {
	   return earningStrategy->earnings();
   }
   void print() const; 

   EarningStrategy *operator += (EarningDecorator * decorator); // add a decorator

private:
   std::string firstName;
   std::string lastName;
   std::string socialSecurityNumber;
   EarningStrategy *earningStrategy;
}; // end class Employee

#endif // EMPLOYEE_H

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
