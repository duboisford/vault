/*
 * TransactionProcessor.h
 *
 *  Created on: Jul 13, 2014
 *      Author: Doug
 */

#ifndef TRANSACTIONPROCESSOR_H_
#define TRANSACTIONPROCESSOR_H_

#include <fstream>
using namespace std;

#include "ClientData.h"

class TransactionProcessor
{
public:
	TransactionProcessor();
	virtual ~TransactionProcessor();

	enum Choices { PRINT = 1, UPDATE, NEW, DELETE, END };

	bool isOpenForTransactions();
	int enterChoice();
	void createTextFile();
	void updateRecord();
	void newRecord();
	void deleteRecord();
	void outputLine(ostream &output, const ClientData &record);
	int getAccount(const char * const prompt);

private:
	fstream inOutCredit;
};

#endif /* TRANSACTIONPROCESSOR_H_ */
