// Fig. 14.14: fig14_14.cpp
// This program reads a random-access file sequentially, updates
// data previously written to the file, creates data to be placed
// in the file, and deletes data previously stored in the file.
#include <iostream>
#include <iomanip>
#include <cstdlib> // exit function prototype
#include "ClientData.h" // ClientData class definition
using namespace std;

#include "TransactionProcessor.h"

int main()
{
	int status = EXIT_SUCCESS;

	TransactionProcessor transactionProcessor;

	// exit program if fstream cannot open file
	if (transactionProcessor.isOpenForTransactions())
	{

		int choice; // store user choice

		// enable user to specify action
		while ((choice = transactionProcessor.enterChoice()) != TransactionProcessor::END)
		{
			switch (choice)
			{
			case TransactionProcessor::PRINT: // create text file from record file
				transactionProcessor.createTextFile ();
				break;
			case TransactionProcessor::UPDATE: // update record
				transactionProcessor.updateRecord();
				break;
			case TransactionProcessor::NEW: // create record
				transactionProcessor.newRecord();
				break;
			case TransactionProcessor::DELETE: // delete existing record
				transactionProcessor.deleteRecord();
				break;
			default: // display error if user does not select valid choice
				cerr << "Incorrect choice" << endl;
				break;
			} // end switch

		} // end while

	}
	else
	{
		cerr << "File could not be opened." << endl;
		status = EXIT_FAILURE;
	} // end if
	return status;
} // end main

/**************************************************************************
 * (C) Copyright 1992-2014 by Deitel & Associates, Inc. and               *
 * Pearson Education, Inc. All Rights Reserved.                           *
 *                                                                        *
 * DISCLAIMER: The authors and publisher of this book have used their     *
 * best efforts in preparing the book. These efforts include the          *
 * development, research, and testing of the theories and programs        *
 * to determine their effectiveness. The authors and publisher make       *
 * no warranty of any kind, expressed or implied, with regard to these    *
 * programs or to the documentation contained in these books. The authors *
 * and publisher shall not be liable in any event for incidental or       *
 * consequential damages in connection with, or arising out of, the       *
 * furnishing, performance, or use of these programs.                     *
 **************************************************************************/
