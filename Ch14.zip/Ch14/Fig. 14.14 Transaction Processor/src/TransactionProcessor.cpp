/*
 * TransactionProcessor.cpp
 *
 *  Created on: Jul 13, 2014
 *      Author: Doug
 */
#include <iomanip>
#include <iostream>
#include <stdlib.h>
using namespace std;

#include "TransactionProcessor.h"

TransactionProcessor::TransactionProcessor()
{
	// open file for reading and writing
	inOutCredit.open("..\\credit.dat", ios::in | ios::out | ios::binary);
}

TransactionProcessor::~TransactionProcessor()
{
	inOutCredit.close();
}

bool TransactionProcessor::isOpenForTransactions()
{
	bool isOpen;

	if (inOutCredit.is_open())
	{
		isOpen = true;
	}
	else
	{
		isOpen = false;
	}
	return isOpen;
}

// enable user to input menu choice
int TransactionProcessor::enterChoice()
{
	// display available options
	cout << "\nEnter your choice" << endl
			<< "1 - store a formatted text file of accounts" << endl
			<< "    called \"credit.txt\" for printing" << endl
			<< "2 - update an account" << endl << "3 - add a new account"
			<< endl << "4 - delete an account" << endl << "5 - end program\n? ";

	int menuChoice;
	cin >> menuChoice; // input menu selection from user
	return menuChoice;
} // end function enterChoice

// create formatted text file for printing
void TransactionProcessor::createTextFile()
{
	// create text file
	ofstream outPrintFile("..\\credit.txt", ios::out);

	// exit program if ofstream cannot create file
	if (!outPrintFile)
	{
		cerr << "File could not be created." << endl;
		exit (EXIT_FAILURE);
	} // end if

	// output column heads
	outPrintFile << left << setw(10) << "Account" << setw(16) << "Last Name"
			<< setw(11) << "First Name" << right << setw(10) << "Balance"
			<< endl;

	// set file-position pointer to beginning of readFromFile
	inOutCredit.seekg(0);

	// read first record from record file
	ClientData client;
	inOutCredit.read(reinterpret_cast<char *>(&client), sizeof(ClientData));

	// copy all records from record file into text file
	while (!inOutCredit.eof())
	{
		// write single record to text file
		if (client.getAccountNumber() != 0) // skip empty records
		{
			outputLine(outPrintFile, client);
		}
		// read next record from record file
		inOutCredit.read(reinterpret_cast<char *>(&client),
				sizeof(ClientData));
	} // end while
	inOutCredit.clear(); // reset end-of-file indicator
} // end function createTextFile

// update balance in record
void TransactionProcessor::updateRecord()
{
	// obtain number of account to update
	int accountNumber = getAccount("Enter account to update");

	// move file-position pointer to correct record in file
	inOutCredit.seekg((accountNumber - 1) * sizeof(ClientData));

	// read first record from file
	ClientData client;
	inOutCredit.read(reinterpret_cast<char *>(&client), sizeof(ClientData));

	// update record
	if (client.getAccountNumber() != 0)
	{
		outputLine(cout, client); // display the record

		// request user to specify transaction
		cout << "\nEnter charge (+) or payment (-): ";
		double transaction; // charge or payment
		cin >> transaction;

		// update record balance
		double oldBalance = client.getBalance();
		client.setBalance(oldBalance + transaction);
		outputLine(cout, client); // display the record

		// move file-position pointer to correct record in file
		inOutCredit.seekp((accountNumber - 1) * sizeof(ClientData));

		// write updated record over old record in file
		inOutCredit.write(reinterpret_cast<const char *>(&client),
				sizeof(ClientData));
	} // end if
	else
	{
		// display error if account does not exist
		cerr << "Account #" << accountNumber << " has no information." << endl;
	}
	inOutCredit.clear(); // reset end-of-file indicator
} // end function updateRecord

// create and insert record
void TransactionProcessor::newRecord()
{
	// obtain number of account to create
	int accountNumber = getAccount("Enter new account number");

	// move file-position pointer to correct record in file
	inOutCredit.seekg((accountNumber - 1) * sizeof(ClientData));

	// read record from file
	ClientData client;
	inOutCredit.read(reinterpret_cast<char *>(&client), sizeof(ClientData));

	// create record, if record does not previously exist
	if (client.getAccountNumber() == 0)
	{
		string lastName;
		string firstName;
		double balance;

		// user enters last name, first name and balance
		cout << "Enter lastname, firstname, balance\n? ";
		cin >> lastName;
		cin >> firstName;
		cin >> balance;

		// use values to populate account values
		client.setLastName(lastName);
		client.setFirstName(firstName);
		client.setBalance(balance);
		client.setAccountNumber(accountNumber);

		// move file-position pointer to correct record in file
		inOutCredit.seekp((accountNumber - 1) * sizeof(ClientData));

		// insert record in file
		inOutCredit.write(reinterpret_cast<const char *>(&client),
				sizeof(ClientData));
	} // end if
	else
	{
		// display error if account already exists
		cerr << "Account #" << accountNumber << " already contains information."
				<< endl;
	}
	inOutCredit.clear(); // reset end-of-file indicator
} // end function newRecord

// delete an existing record
void TransactionProcessor::deleteRecord()
{
	// obtain number of account to delete
	int accountNumber = getAccount("Enter account to delete");

	// move file-position pointer to correct record in file
	inOutCredit.seekg((accountNumber - 1) * sizeof(ClientData));

	// read record from file
	ClientData client;
	inOutCredit.read(reinterpret_cast<char *>(&client), sizeof(ClientData));

	// delete record, if record exists in file
	if (client.getAccountNumber() != 0)
	{
		ClientData blankClient; // create blank record

		// move file-position pointer to correct record in file
		inOutCredit.seekp((accountNumber - 1) * sizeof(ClientData));

		// replace existing record with blank record
		inOutCredit.write(reinterpret_cast<const char *>(&blankClient),
				sizeof(ClientData));

		cout << "Account #" << accountNumber << " deleted.\n";
	} // end if
	else
	{
		// display error if record does not exist
		cerr << "Account #" << accountNumber << " is empty.\n";
	}
	inOutCredit.clear(); // reset end-of-file indicator
} // end deleteRecord

// display single record
void TransactionProcessor::outputLine(ostream &output, const ClientData &record)
{
	output << left << setw(10) << record.getAccountNumber() << setw(16)
			<< record.getLastName() << setw(11) << record.getFirstName()
			<< setw(10) << setprecision(2) << right << fixed << showpoint
			<< record.getBalance() << endl;
} // end function outputLine

// obtain account-number value from user
int TransactionProcessor::getAccount(const char * const prompt)
{
	int accountNumber;

	// obtain account-number value
	do
	{
		cout << prompt << " (1 - 100): ";
		cin >> accountNumber;
	} while (accountNumber < 1 || accountNumber > 100);

	return accountNumber;
} // end function getAccount

